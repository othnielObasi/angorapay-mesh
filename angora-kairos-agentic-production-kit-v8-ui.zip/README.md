# Angora Market Intelligence Agents

Production-grade integration kit for **specialised market-intelligence agents** powered by the **Angora Gateway / SDK / AngoraPay Mesh**.

Angora helps market-facing AI systems buy trusted intelligence before they act. It combines specialist agents, provider routing, policy controls, Circle/x402 payment flows, proof receipts, traces, reconciliation, and multi-tenant workspace controls.

> **Core position:** Circle/x402 provides the payment rail. Angora provides the agentic decision, trust, routing, proof, reconciliation, and developer adoption layer around those payments.

---

## 1. What This Kit Contains

This repository is a production-oriented Angora/Kairos integration kit. It includes:

- A multi-agent market-intelligence runtime.
- Three specialist agents.
- Angora Gateway API routes.
- Provider discovery and route scoring.
- Policy, spend, and trust controls.
- Circle/x402 adapter boundaries with explicit payment modes.
- Payment, delivery, receipt, and reconciliation ledgers.
- Persistent conversation and trace stores.
- Multi-tenant workspace foundations.
- API key auth, scopes, and rate limiting.
- Provider onboarding APIs.
- Product dashboard HTML surface.
- TypeScript SDK.
- Python SDK.
- Docker and production environment templates.
- PostgreSQL production schema target.
- Smoke tests and full validation scripts.

This kit is designed to be merged into the existing Kairos/Angora application while keeping the Gateway, SDK, payment, proof, and agentic layers cleanly separated.

---

## 2. Product Purpose

Market agents need external intelligence before making or recommending market action. They may need:

- prediction-market odds,
- sentiment feeds,
- liquidity checks,
- risk checks,
- cross-venue price feeds,
- slippage estimates,
- trader-performance data,
- social-alpha signals,
- proof writers.

The hard problem is not simply whether an agent can pay for a service. The real problem is:

> Which intelligence should the agent buy, which provider should it trust, what should be blocked, how should payment happen, and how can the paid signal be proven and reconciled later?

Angora solves this with the following flow:

```text
Mission
→ specialist agent
→ context + policy
→ provider discovery
→ route scoring
→ policy/spend evaluation
→ Circle/x402 payment boundary
→ provider delivery
→ output hash
→ receipt/proof
→ trace
→ reconciliation
→ recommendation
```

---

## 3. Core User Groups

### Agent builders and developers

Developers building market-facing AI agents can use the SDK/API to run paid-intelligence missions and retrieve receipts, traces, and reconciliation state.

### Market teams and analysts

Teams can use the Agent Missions workspace to run prediction-market, arbitrage, or social-trading intelligence missions.

### Paid intelligence providers

Providers can register x402-compatible services such as odds feeds, sentiment APIs, risk checks, arbitrage feeds, liquidity data, social-trading intelligence, or proof-writing services.

### Workspace admins

Admins manage workspace members, API keys, provider access, budgets, policies, and audit logs.

### Auditors and evaluators

Auditors can inspect traces, payment records, provider deliveries, proof receipts, reconciliation outcomes, and policy decisions.

---

## 4. Specialist Agents

### 4.1 Prediction Market Intelligence Agent

Evaluates whether a prediction market may be mispriced or +EV.

Example mission:

```text
Check whether this BTC prediction market is mispriced after the news shift.
```

Typical intelligence:

- odds feed,
- liquidity depth,
- sentiment feed,
- probability shift,
- risk check,
- proof receipt.

Output:

- recommendation: `enter`, `monitor`, `avoid`, or `reduce_size`,
- confidence score,
- approved providers,
- blocked providers,
- USDC routed,
- receipts,
- trace link,
- reconciliation state.

### 4.2 Cross-Venue Arbitrage Agent

Evaluates whether a price gap across venues is executable after fees, slippage, liquidity, latency, and risk.

Example mission:

```text
Check whether the BTC price gap across two venues survives fees and slippage.
```

Typical intelligence:

- venue price feeds,
- spread check,
- liquidity check,
- fee estimate,
- slippage estimate,
- execution-risk check,
- proof receipt.

### 4.3 Social Trading Intelligence Agent

Evaluates whether a trader, influencer, or social-alpha signal is reliable enough to follow.

Example mission:

```text
Evaluate whether this trader signal is reliable enough to follow with reduced size.
```

Typical intelligence:

- trader history,
- signal consistency,
- social sentiment,
- copy-risk score,
- drawdown pattern,
- source credibility,
- proof receipt.

---

## 5. Architecture

```text
Frontend / Dashboard / External App
        ↓
Angora API Routes
        ↓
Agent Mission Service
        ↓
Mission Classifier + Specialist Agent Runtime
        ↓
Context Builder + Adaptive Memory + Checkpoints
        ↓
Angora Gateway
        ↓
Provider Search → Route Score → Policy/Spend Check
        ↓
Circle/x402 Adapter Boundary
        ↓
Provider Delivery → Output Hash → Receipt
        ↓
Payment Ledger + Delivery Ledger + Reconciliation Ledger
        ↓
Conversation History + Traces + Metrics + Audit Logs
```

### Important design principle

The agents are the product surface. The Gateway/SDK/payment/proof/reconciliation layer is the production infrastructure that makes them trustworthy.

---

## 6. Current Production Status

This kit is production-oriented and includes the full operational structure needed for real-world use. It supports local file-backed state for fast deployment and includes the PostgreSQL schema target for production database deployment.

### Implemented in this kit

- Specialist agent missions.
- Conversations.
- Agent traces.
- Mission checkpoints.
- Workspace foundation.
- Workspace members and roles.
- Workspace policies.
- Workspace budgets.
- Workspace provider access.
- API key auth and scopes.
- Rate limiting.
- Provider onboarding.
- Provider validation.
- Payment intents.
- Payment events.
- Provider deliveries.
- Receipts.
- Webhook events.
- Production reconciliation runs and items.
- Audit logs.
- Metrics.
- Dashboard UI surface.
- TypeScript SDK.
- Python SDK.
- Dockerfile.
- Docker Compose.
- Health and readiness endpoints.
- PostgreSQL migration schema target.

### Storage status

The default runtime still uses JSON-backed local storage so the kit can run immediately on local/Vultr/demo deployments without a database.

Production deployment should use the included PostgreSQL migration target and repository adapters should be wired behind the existing store interfaces for durable production mode.

See:

```text
src/agora/db/README.md
src/agora/db/migrations/001_angora_platform.sql
```

### Payment status

Payment modes are explicit and must remain explicit:

```text
real_x402
arc_testnet
demo_fallback
blocked
failed
pending
local_proof
```

The kit is designed so demo/fallback mode never pretends to be real settlement.

---

## 7. Repository Structure

```text
.
├── README.md
├── INTEGRATION_PATCH.md
├── Dockerfile.agora
├── docker-compose.agora.yml
├── .env.production.example
├── package.json
├── src/
│   └── agora/
│       ├── routes.ts
│       ├── auth-manager.ts
│       ├── workspace-store.ts
│       ├── policy-engine.ts
│       ├── service-registry.ts
│       ├── route-simulator.ts
│       ├── trust-scorecard.ts
│       ├── circle-x402-adapter.ts
│       ├── payment-ledger.ts
│       ├── provider-delivery-store.ts
│       ├── receipt-store.ts
│       ├── reconciliation-service.ts
│       ├── reconciliation-ledger.ts
│       ├── webhook-event-store.ts
│       ├── audit-log.ts
│       ├── observability.ts
│       ├── db/
│       │   ├── README.md
│       │   └── migrations/
│       │       └── 001_angora_platform.sql
│       └── agentic/
│           ├── agent-mission-service.ts
│           ├── mission-classifier.ts
│           ├── adaptive-memory.ts
│           ├── recommendation-engine.ts
│           ├── conversation-store.ts
│           ├── trace-store.ts
│           ├── checkpoint-store.ts
│           └── types.ts
├── sdk/
│   ├── typescript/
│   └── python/
└── docs/
    ├── AGENTIC_MERGE_NOTES.md
    ├── PRODUCTION_RECONCILIATION_LEDGER.md
    ├── PRODUCTION_COMPLETION_NOTES_V7.md
    ├── PRODUCTION_HARDENING_NOTES.md
    └── AGORA_CLOSEOUT_PLAN.md
```

---

## 8. Quick Start

### 8.1 Install dependencies

```bash
npm install
```

### 8.2 Run full validation

```bash
npm run agora:full-check
```

This runs:

```bash
npm run agora:typecheck
npm run agora:self-test
npm run agora:sdk:python:check
npm run agora:agentic-smoke
npm run agora:reconciliation-smoke
```

### 8.3 Run the agentic smoke test

```bash
npm run agora:agentic-smoke
```

Expected shape:

```json
{
  "mission": "...",
  "module": "prediction_market",
  "receipts": 4,
  "traces": 26,
  "checkpoints": 7
}
```

### 8.4 Run reconciliation smoke test

```bash
npm run agora:reconciliation-smoke
```

Expected shape:

```json
{
  "mission": "...",
  "receipts": 4,
  "reconciliationRun": "...",
  "checked": 4,
  "matched": 0,
  "pending": 4,
  "failed": 0
}
```

In demo/fallback mode, pending reconciliation is expected because the platform correctly does not claim final real settlement.

---

## 9. Environment Configuration

### 9.1 Local/default mode

The kit can run with JSON local state using:

```bash
AGORA_STATE_DIR=.kairos-agora
AGORA_STORAGE_DRIVER=json-file
CIRCLE_X402_MODE=demo_fallback
```

### 9.2 Production-style environment

Use `.env.production.example` as the production template:

```bash
NODE_ENV=production
AGORA_REQUIRE_AUTH=true
AGORA_API_KEY_PREFIX=ag_live
AGORA_DEFAULT_WORKSPACE_ID=prod-workspace
AGORA_DEFAULT_TENANT_ID=prod-workspace
AGORA_STATE_DIR=/var/lib/angora/state
AGORA_STORAGE_DRIVER=postgres
DATABASE_URL=postgres://angora:change_me@localhost:5432/angora
REDIS_URL=redis://localhost:6379
AGORA_GATEWAY_RATE_LIMIT_MAX=120
CIRCLE_X402_MODE=real_x402
CIRCLE_API_KEY=replace_me
CIRCLE_WALLET_ID=replace_me
ARC_NETWORK=arc-mainnet-or-testnet
WEBHOOK_SIGNING_SECRET=replace_me
```

### 9.3 Auth mode

When `AGORA_REQUIRE_AUTH=true`, protected routes require an Agora API key with the needed scope.

When `AGORA_REQUIRE_AUTH=false`, the local runtime can be used for development/demo mode.

---

## 10. Docker and Deployment

### 10.1 Dockerfile

```text
Dockerfile.agora
```

### 10.2 Docker Compose

```bash
docker compose -f docker-compose.agora.yml up --build
```

The compose file is intended for local production-like deployment and can be adapted for Vultr, a VM, or a container platform.

### 10.3 Health checks

```http
GET /v1/agora/health
GET /v1/agora/ready
```

`/health` confirms the service is running.

`/ready` reports runtime storage driver and state directory configuration.

---

## 11. Multi-Tenant Workspace Model

Angora uses workspaces as tenants.

Each workspace owns its own:

- users/members,
- roles,
- conversations,
- missions,
- traces,
- checkpoints,
- policies,
- budgets,
- provider access,
- API keys,
- payment records,
- receipts,
- reconciliation runs,
- metrics,
- audit logs.

### Workspace entities

Implemented in:

```text
src/agora/workspace-store.ts
```

Core types:

- `Workspace`
- `WorkspaceMember`
- `WorkspacePolicy`
- `WorkspaceBudget`
- `WorkspaceProviderAccess`

### Roles

Supported role model:

```text
owner
admin
builder
analyst
provider
viewer
```

### Workspace APIs

```http
POST  /v1/agora/workspaces
GET   /v1/agora/workspaces
GET   /v1/agora/workspaces/current
PATCH /v1/agora/workspaces/current
GET   /v1/agora/workspaces/current/members
POST  /v1/agora/workspaces/current/members
GET   /v1/agora/workspaces/current/policy
PATCH /v1/agora/workspaces/current/policy
GET   /v1/agora/workspaces/current/budget
PATCH /v1/agora/workspaces/current/budget
GET   /v1/agora/workspaces/current/provider-access
POST  /v1/agora/workspaces/current/provider-access
GET   /v1/agora/audit-logs
```

### Important production rule

Every production query must be scoped by the authenticated workspace.

```ts
// Correct
listReceipts({ workspaceId });

// Incorrect
listReceipts();
```

---

## 12. Authentication, API Keys, and Scopes

Implemented in:

```text
src/agora/auth-manager.ts
```

### API key routes

```http
POST /v1/agora/auth/keys
GET  /v1/agora/auth/keys
POST /v1/agora/auth/keys/rotate
POST /v1/agora/auth/keys/:keyId/revoke
```

### Example scopes

```text
admin
workspace:read
workspace:write
missions:read
missions:write
gateway:call
receipts:read
history:read
metrics:read
settlement:read
settlement:write
```

### API key behavior

API keys should be workspace-scoped and should carry:

- workspace ID,
- tenant ID,
- subject ID,
- allowed scopes,
- environment mode,
- revocation status,
- last-used metadata.

---

## 13. Agent Missions

Implemented in:

```text
src/agora/agentic/agent-mission-service.ts
src/agora/agentic/mission-classifier.ts
src/agora/agentic/recommendation-engine.ts
src/agora/agentic/adaptive-memory.ts
src/agora/agentic/conversation-store.ts
src/agora/agentic/trace-store.ts
src/agora/agentic/checkpoint-store.ts
```

### Run mission endpoint

```http
POST /v1/agora/agent-missions/run
```

### Example request

```json
{
  "userGoal": "Check whether this BTC prediction market is mispriced after the news shift.",
  "paymentMode": "demo_fallback",
  "maxSpendUSDC": "0.05",
  "minProviderTrustScore": 85,
  "proofRequired": true
}
```

### Example response shape

```json
{
  "missionId": "mission_...",
  "conversationId": "conv_...",
  "specialistAgent": "prediction_market",
  "recommendation": {
    "decision": "monitor",
    "confidence": 0.72
  },
  "receipts": [],
  "traces": [],
  "checkpoints": []
}
```

### Conversations

```http
GET /v1/agora/conversations
GET /v1/agora/conversations/:conversationId
```

### Traces and checkpoints

```http
GET /v1/agora/agent-traces
GET /v1/agora/agent-checkpoints
```

---

## 14. Gateway Flow

The Gateway handles provider discovery, route scoring, policy checks, spend checks, payment boundaries, receipt generation, and execution history.

### Gateway call endpoint

```http
POST /v1/agora/gateway/call
```

### Core flow

```text
Request received
→ auth and rate limit
→ idempotency check
→ mission lookup
→ service discovery
→ policy evaluation
→ spend limit evaluation
→ provider selected or blocked
→ x402 adapter called if approved
→ provider delivery recorded
→ receipt created
→ payment intent/event stored
→ execution history stored
→ response returned
```

### Supporting routes

```http
POST /v1/agora/missions
GET  /v1/agora/missions
GET  /v1/agora/services/search
GET  /v1/agora/rfps
GET  /v1/agora/route/simulate
POST /v1/agora/demo/market-mission
```

---

## 15. Provider Marketplace and Onboarding

Provider registration and validation are implemented in:

```text
src/agora/service-registry.ts
```

### Routes

```http
POST /v1/agora/providers/register
POST /v1/agora/providers/:providerId/validate
GET  /v1/agora/services/search
GET  /v1/agora/reputation
```

### Provider registration example

```json
{
  "providerId": "oddsnode",
  "name": "Prediction Market Odds API",
  "category": "odds",
  "priceUSDC": "0.004",
  "x402Endpoint": "https://oddsnode.example/x402",
  "proofSupported": true,
  "arcSupported": true,
  "latencySlaMs": 500
}
```

### Provider access controls

Workspace admins can mark providers as:

```text
allowed
blocked
preferred
```

---

## 16. Policy, Trust, and Spend Controls

Implemented in:

```text
src/agora/policy-engine.ts
src/agora/trust-scorecard.ts
src/agora/spend-limits.ts
src/agora/workspace-store.ts
```

### Controls

- max mission spend,
- daily spend limit,
- minimum provider trust,
- minimum route score,
- proof required,
- allowed categories,
- blocked providers,
- allowed payment modes,
- fallback allowed/disabled.

### Example symbolic rules

```text
IF provider.trust < minProviderTrust THEN block
IF routeScore < minRouteScore THEN block
IF proofRequired AND provider.proofSupported = false THEN block
IF budgetRemaining < provider.price THEN block payment
IF paymentStatus != authorized THEN do not unlock service
IF receiptMissing THEN mission cannot complete
IF idempotencyKey already used THEN do not repeat payment
```

---

## 17. Payments, Delivery, Receipts, and Reconciliation

### Payment ledger

Implemented in:

```text
src/agora/payment-ledger.ts
```

Routes:

```http
GET /v1/agora/payment-intents
GET /v1/agora/payment-events
```

### Provider deliveries

Implemented in:

```text
src/agora/provider-delivery-store.ts
```

Route:

```http
GET /v1/agora/provider-deliveries
```

### Receipts

Implemented in:

```text
src/agora/receipt-store.ts
```

Routes:

```http
GET /v1/agora/receipts
GET /v1/agora/receipts/:receiptId
```

### Webhook events

Implemented in:

```text
src/agora/webhook-event-store.ts
```

Routes:

```http
POST /v1/agora/webhooks/payment
GET  /v1/agora/webhooks
```

### Production reconciliation

Implemented in:

```text
src/agora/reconciliation-service.ts
src/agora/reconciliation-ledger.ts
src/agora/reconciliation-types.ts
```

Routes:

```http
POST /v1/agora/reconciliation/run
GET  /v1/agora/reconciliation/runs
```

### Legacy/simple settlement reconciliation

```http
POST /v1/agora/settlement/reconcile
```

This exists for compatibility with earlier integration flows.

### Reconciliation statuses

```text
matched
pending_payment
pending_delivery
paid_but_not_delivered
delivered_but_payment_unconfirmed
amount_mismatch
provider_mismatch
duplicate_payment
receipt_missing
fallback
blocked
manual_review_required
```

---

## 18. Circle/x402 Adapter Boundary

Implemented in:

```text
src/agora/circle-x402-adapter.ts
```

The adapter is intentionally isolated so demo, testnet, and real x402 integrations can be swapped without changing the agent or route-scoring logic.

### Required production hardening for real payments

Before live money movement, ensure:

- live/sandbox config separation,
- payment authorization verification,
- webhook signature verification,
- provider unlock verification,
- replay/idempotency protection,
- timeout and retry policies,
- manual review handling,
- transaction reference validation.

---

## 19. Idempotency and Replay Protection

Implemented in:

```text
src/agora/idempotency-store.ts
```

Every external payment/provider call should use an idempotency key.

Example format:

```text
mission_123:provider_oddsnode:service_odds:attempt_001
```

Rules:

```text
IF idempotency key already completed THEN return previous result
IF payment reference already exists THEN do not create duplicate payment
IF receipt already exists for mission/provider/service/idempotency key THEN do not duplicate receipt
IF webhook event ID already processed THEN skip duplicate processing
```

---

## 20. Conversation History, Traces, and Checkpoints

### Conversations

Conversations are the ChatGPT-style mission history. Users can reopen prior market-agent missions.

Implemented in:

```text
src/agora/agentic/conversation-store.ts
```

### Traces

Traces show what happened during the mission:

- mission created,
- agent selected,
- context prepared,
- providers scanned,
- route scored,
- provider blocked,
- payment attempted,
- receipt created,
- reconciliation checked,
- recommendation returned.

Implemented in:

```text
src/agora/agentic/trace-store.ts
```

### Checkpoints

Checkpoints are internal recovery state used to safely resume missions.

Implemented in:

```text
src/agora/agentic/checkpoint-store.ts
```

Checkpoints are mainly for operations/debugging and should be visible through trace inspectors or recovery views.

---

## 21. Metrics and Traction

Implemented in:

```text
src/agora/submission-metrics.ts
src/agora/traction-store.ts
src/agora/observability.ts
```

Routes:

```http
POST /v1/agora/traction/users
POST /v1/agora/traction/feedback
GET  /v1/agora/traction/summary
GET  /v1/agora/runtime/metrics
GET  /v1/agora/submission/metrics
GET  /v1/agora/dashboard/summary
```

Metrics include:

- users onboarded,
- missions created,
- conversations,
- paid calls,
- blocked calls,
- receipts,
- USDC routed,
- real x402 calls,
- testnet/fallback calls,
- providers used,
- repeat users,
- SDK calls.

---

## 22. Dashboard / Product UI

The included dashboard surface is:

```text
src/dashboard/public/agora.html
```

The UI direction is:

### Product workspace

- Agent Missions
- Conversations
- Use Cases

### Infrastructure console

- Gateway
- Marketplace
- Route Scorecard
- Policy
- Payments
- Reconciliation
- Proof
- Traces
- Metrics
- Developers
- Providers
- Settings

### UI principle

Do not bury the infrastructure. The product should clearly show both layers:

```text
Product layer: specialist market-intelligence agents
Infrastructure layer: Gateway, SDK, route scoring, policy, x402, receipts, reconciliation
```

---

## 23. SDKs

### TypeScript SDK

Location:

```text
sdk/typescript/angorapay.ts
```

### Python SDK

Location:

```text
sdk/python/angorapay.py
```

### SDK capabilities

- run agent mission,
- run gateway call,
- fetch conversations,
- fetch traces,
- fetch payment intents/events,
- fetch provider deliveries,
- fetch receipts,
- run reconciliation,
- register providers,
- fetch metrics.

### TypeScript example

```ts
import { AngoraPay } from "@angorapay/sdk";

const angora = new AngoraPay({
  apiKey: process.env.ANGORA_API_KEY!,
  gatewayUrl: process.env.ANGORA_GATEWAY_URL!,
});

const result = await angora.runAgentMission({
  userGoal: "Check whether this BTC prediction market is mispriced.",
  paymentMode: "demo_fallback",
});
```

### Python example

```python
from angorapay import AngoraPay

client = AngoraPay(
    api_key="ag_live_xxx",
    gateway_url="https://your-domain.example"
)

result = client.run_agent_mission({
    "userGoal": "Check whether this BTC prediction market is mispriced.",
    "paymentMode": "demo_fallback"
})
```

---

## 24. PostgreSQL Production Schema

The production database schema target is located at:

```text
src/agora/db/migrations/001_angora_platform.sql
```

It covers durable storage for:

- workspaces,
- workspace members,
- API keys,
- conversations,
- messages,
- missions,
- checkpoints,
- traces,
- provider services,
- route evaluations,
- policy evaluations,
- payment intents,
- payment events,
- provider deliveries,
- receipts,
- reconciliation runs,
- reconciliation items,
- audit logs.

### Production note

The current local runtime uses JSON file-backed stores by default. Production deployment should use the PostgreSQL schema and repository adapters behind the existing domain store interfaces.

This separation is intentional so local/demo deployment stays simple while the production data model remains defined.

---

## 25. API Reference Summary

### Health and readiness

```http
GET /v1/agora/health
GET /v1/agora/ready
```

### Workspace and tenancy

```http
POST  /v1/agora/workspaces
GET   /v1/agora/workspaces
GET   /v1/agora/workspaces/current
PATCH /v1/agora/workspaces/current
GET   /v1/agora/workspaces/current/members
POST  /v1/agora/workspaces/current/members
GET   /v1/agora/workspaces/current/policy
PATCH /v1/agora/workspaces/current/policy
GET   /v1/agora/workspaces/current/budget
PATCH /v1/agora/workspaces/current/budget
GET   /v1/agora/workspaces/current/provider-access
POST  /v1/agora/workspaces/current/provider-access
GET   /v1/agora/audit-logs
```

### Auth and API keys

```http
POST /v1/agora/auth/keys
GET  /v1/agora/auth/keys
POST /v1/agora/auth/keys/rotate
POST /v1/agora/auth/keys/:keyId/revoke
```

### Agentic missions

```http
POST /v1/agora/agent-missions/run
GET  /v1/agora/conversations
GET  /v1/agora/conversations/:conversationId
GET  /v1/agora/agent-traces
GET  /v1/agora/agent-checkpoints
```

### Gateway and missions

```http
POST /v1/agora/missions
GET  /v1/agora/missions
POST /v1/agora/gateway/call
POST /v1/agora/demo/market-mission
GET  /v1/agora/services/search
GET  /v1/agora/rfps
GET  /v1/agora/route/simulate
```

### Providers

```http
POST /v1/agora/providers/register
POST /v1/agora/providers/:providerId/validate
GET  /v1/agora/reputation
```

### Receipts, execution, and settlement

```http
GET  /v1/agora/receipts
GET  /v1/agora/receipts/:receiptId
GET  /v1/agora/execution-history
POST /v1/agora/settlement/reconcile
```

### Production reconciliation

```http
POST /v1/agora/reconciliation/run
GET  /v1/agora/reconciliation/runs
GET  /v1/agora/payment-intents
GET  /v1/agora/payment-events
GET  /v1/agora/provider-deliveries
POST /v1/agora/webhooks/payment
GET  /v1/agora/webhooks
```

### Metrics and traction

```http
POST /v1/agora/traction/users
POST /v1/agora/traction/feedback
GET  /v1/agora/traction/summary
GET  /v1/agora/runtime/metrics
GET  /v1/agora/submission/metrics
GET  /v1/agora/dashboard/summary
```

---

## 26. Validation and Test Commands

### TypeScript typecheck

```bash
npm run agora:typecheck
```

### Self-test

```bash
npm run agora:self-test
```

### Python SDK compile check

```bash
npm run agora:sdk:python:check
```

### Agentic smoke test

```bash
npm run agora:agentic-smoke
```

### Reconciliation smoke test

```bash
npm run agora:reconciliation-smoke
```

### Full check

```bash
npm run agora:full-check
```

---

## 27. Production Readiness Checklist

Before deploying for real users:

- [ ] Set `AGORA_REQUIRE_AUTH=true`.
- [ ] Use scoped API keys.
- [ ] Configure workspace policies and budgets.
- [ ] Configure allowed payment modes.
- [ ] Keep demo/testnet/live payment modes explicit.
- [ ] Run `npm run agora:full-check`.
- [ ] Configure persistent storage.
- [ ] Apply PostgreSQL migration for production database.
- [ ] Wire repository adapters to PostgreSQL for production mode.
- [ ] Configure webhook signing secret.
- [ ] Verify provider endpoint validation.
- [ ] Verify idempotency behavior.
- [ ] Verify reconciliation status handling.
- [ ] Review audit logs.
- [ ] Confirm tenant isolation.
- [ ] Configure deployment health checks.

---

## 28. Known Boundaries and Honest Limitations

This kit has the production structure, schemas, APIs, and operational layers needed for Angora, but there are two boundaries to keep explicit:

1. **Storage driver:** JSON file storage is the default local/demo mode. PostgreSQL schema is included for production, and production repository adapters should be wired behind existing stores before high-scale multi-user deployment.

2. **Payment mode:** real x402 should only be enabled after live Circle/x402 credentials, provider endpoint verification, webhook signature verification, and settlement validation are configured.

These boundaries are intentional and should be communicated clearly in deployments and demos.

---

## 29. Related Documentation

```text
docs/AGENTIC_MERGE_NOTES.md
docs/PRODUCTION_RECONCILIATION_LEDGER.md
docs/PRODUCTION_COMPLETION_NOTES_V7.md
docs/PRODUCTION_HARDENING_NOTES.md
docs/AGORA_CLOSEOUT_PLAN.md
src/agora/db/README.md
src/agora/db/migrations/001_angora_platform.sql
sdk/typescript/README.md
sdk/python/README.md
```

---

## 30. Strategic Summary

Angora should be understood as the **paid-intelligence operating layer for market agents**.

Specialist agents make the platform usable.

Gateway/SDK/payment/proof/reconciliation infrastructure makes it credible.

Multi-tenancy makes it usable by real teams.

Receipts, traces, and reconciliation make it trustworthy.

Circle/x402/USDC make the paid-service workflow commercially meaningful.

The value proposition is simple:

> Teams can run market-intelligence agents that buy trusted paid signals, block weak providers, control spend, generate proof, and reconcile payment with delivery — through a UI or SDK.


## UI Product Upgrade V8

The dashboard UI has been upgraded to make the product clearer without burying the infrastructure layer. The UI now separates Angora into:

- **Product workspace:** Agent Missions, Conversations, Use Cases.
- **Infrastructure console:** Gateway, Marketplace, Route Scorecard, Policy, Payments, Reconciliation, Proof.
- **Operations and adoption:** Traces, Metrics, Providers, Settings, Developers.

The main page is now a calmer agent mission workspace: users choose a specialist agent, run a market-intelligence mission, and inspect the proof rail. The Gateway/SDK/payment/proof/reconciliation side remains visible through dedicated infrastructure pages.

See `docs/UI_PRODUCT_UPGRADE_V8.md` for the design intent and page structure.
