import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "fs";
import { dirname, join } from "path";

export function agoraStateDir() {
  return (
    process.env.AGORA_STATE_DIR ||
    process.env.KAIROS_AGORA_STATE_DIR ||
    (process.env.KAIROS_DATA_DIR ? join(process.env.KAIROS_DATA_DIR, "agora") : join(process.cwd(), ".kairos-agora"))
  );
}

export function ensureAgoraStateDir() {
  const dir = agoraStateDir();
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
  return dir;
}

export function stateFile(name: string) {
  return join(ensureAgoraStateDir(), name);
}

export function readJsonFile<T>(filePath: string, fallback: T): T {
  if (!existsSync(filePath)) return fallback;
  try {
    return JSON.parse(readFileSync(filePath, "utf8")) as T;
  } catch {
    return fallback;
  }
}

export function writeJsonFile(filePath: string, data: unknown) {
  const dir = dirname(filePath);
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
  const tmp = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  writeFileSync(tmp, JSON.stringify(data, null, 2));
  renameSync(tmp, filePath);
}
