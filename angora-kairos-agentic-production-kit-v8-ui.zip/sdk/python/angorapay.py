from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional
from urllib.parse import urlencode

import requests


@dataclass
class AngoraPay:
    base_url: str
    api_key: Optional[str] = None
    timeout: int = 30

    def _headers(self) -> Dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _request(self, method: str, path: str, **kwargs: Any) -> Dict[str, Any]:
        response = requests.request(
            method,
            f"{self.base_url.rstrip('/')}{path}",
            headers=self._headers(),
            timeout=self.timeout,
            **kwargs,
        )
        try:
            payload = response.json()
        except Exception:
            payload = {"raw": response.text}
        if response.status_code >= 400:
            raise RuntimeError(payload.get("error") or f"Angora request failed with {response.status_code}")
        return payload

    def create_mission(self, **payload: Any) -> Dict[str, Any]:
        return self._request("POST", "/v1/agora/missions", json=payload)

    def discover_market_services(self, **params: Any) -> Dict[str, Any]:
        return self._request("GET", f"/v1/agora/services/search?{urlencode(params)}")

    def simulate_route(self, mission_id: Optional[str] = None, max_price: str = "0.01") -> Dict[str, Any]:
        params = {"max_price": max_price}
        if mission_id:
            params["mission_id"] = mission_id
        return self._request("GET", f"/v1/agora/route/simulate?{urlencode(params)}")

    def call_market_service(self, **payload: Any) -> Dict[str, Any]:
        return self._request("POST", "/v1/agora/gateway/call", json=payload)

    def run_demo_market_mission(self, payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return self._request("POST", "/v1/agora/demo/market-mission", json={"payload": payload or {}})

    def record_user(self, **payload: Any) -> Dict[str, Any]:
        return self._request("POST", "/v1/agora/traction/users", json=payload)

    def record_feedback(self, **payload: Any) -> Dict[str, Any]:
        return self._request("POST", "/v1/agora/traction/feedback", json=payload)

    def execution_history(self, **params: Any) -> Dict[str, Any]:
        return self._request("GET", f"/v1/agora/execution-history?{urlencode(params)}")

    def submission_metrics(self) -> Dict[str, Any]:
        return self._request("GET", "/v1/agora/submission/metrics")

    def run_agent_mission(self, **payload: Any) -> Dict[str, Any]:
        return self._request("POST", "/v1/agora/agent-missions/run", json=payload)

    def conversations(self, **params: Any) -> Dict[str, Any]:
        return self._request("GET", f"/v1/agora/conversations?{urlencode(params)}")

    def conversation(self, conversation_id: str) -> Dict[str, Any]:
        return self._request("GET", f"/v1/agora/conversations/{conversation_id}")

    def agent_traces(self, **params: Any) -> Dict[str, Any]:
        return self._request("GET", f"/v1/agora/agent-traces?{urlencode(params)}")

    def run_reconciliation(self, **payload: Any) -> Dict[str, Any]:
        return self._request("POST", "/v1/agora/reconciliation/run", json=payload)

    def reconciliation_runs(self, **params: Any) -> Dict[str, Any]:
        return self._request("GET", f"/v1/agora/reconciliation/runs?{urlencode(params)}")

    def payment_intents(self, **params: Any) -> Dict[str, Any]:
        return self._request("GET", f"/v1/agora/payment-intents?{urlencode(params)}")
