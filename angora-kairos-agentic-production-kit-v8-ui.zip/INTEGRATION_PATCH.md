# AngoraPay Mesh integration patch for Kairos

## 1. Clone Kairos

```bash
git clone https://github.com/othnielObasi/kairos.git angorapay-mesh
cd angorapay-mesh
git checkout -b feature/angora-market-agent-mesh
```

## 2. Copy this kit

Copy this kit's `src/`, `sdk/`, and `docs/` directories into the cloned Kairos repository.

## 3. Mount routes

Open `src/dashboard/server.ts` and add:

```ts
import { registerAgoraRoutes } from "../agora/routes.js";
```

Then call the route registration after the Express app and middleware are initialized:

```ts
registerAgoraRoutes(app);
```

## 4. Open UI

```text
/agora.html
```

## 5. Run demo mission

```bash
curl -X POST http://localhost:3000/v1/agora/demo/market-mission \
  -H 'Content-Type: application/json' \
  -d '{"payload":{"asset":"BTC","market":"BTC election odds market","horizon":"intraday"}}'
```

Then inspect:

```text
/v1/agora/rfps
/v1/agora/route/simulate
/v1/agora/execution-history
/v1/agora/submission/metrics
/v1/agora/receipts
```

## 6. Capture real users and feedback

```bash
curl -X POST http://localhost:3000/v1/agora/traction/users \
  -H 'Content-Type: application/json' \
  -d '{"userId":"tester-01","displayName":"Test Builder","source":"hackathon"}'

curl -X POST http://localhost:3000/v1/agora/traction/feedback \
  -H 'Content-Type: application/json' \
  -d '{"userId":"tester-01","missionId":"mission_prediction_market_001","rating":5,"comment":"Clear proof trail for market-agent service calls."}'
```

## 7. Mock vs real Circle/x402

Default is mock/fallback mode for local development.

Set this to route approved calls through the existing Kairos x402 paying client:

```bash
KAIROS_ENABLE_REAL_X402=true
```

Set this to label mock calls as Arc testnet simulation in the evidence layer:

```bash
AGORA_DEMO_ARC_TESTNET=true
```

## 8. Production hardening now included

This update adds:

- RFP catalog for all six areas of interest;
- market-agent default mission;
- RFP-aligned market services;
- route simulation;
- route trust scorecards;
- execution history ledger;
- submission metrics endpoint;
- traction user and feedback endpoints;
- idempotency handling;
- optional API-key auth;
- Arc/USDC/Circle/x402 receipt fields;
- audit artifact builder;
- TypeScript and Python SDK starter clients;
- self-test script.

## 9. What remains outside this kit

- Real Circle account setup and live x402 provider endpoints.
- Persistent database migration from JSON files to SQLite/Postgres.
- Hosted public URL and traction collection.
- Final GitHub README/submission video polish.

## Production-MVP hardening patch

Copy these new files into the cloned Kairos repo:

```text
src/agora/schemas.ts
src/agora/idempotency-store.ts
src/agora/observability.ts
src/agora/rate-limiter.ts
src/agora/spend-limits.ts
src/agora/settlement-reconciler.ts
Dockerfile.agora
package.additions.json
.github/workflows/agora-integration.yml
docs/PRODUCTION_HARDENING_NOTES.md
```

Then merge `package.additions.json` into the existing Kairos `package.json`.

SQLite/Postgres persistence is intentionally deferred; this patch keeps the kit portable while adding validation, idempotency, rate limits, structured logs, metrics, settlement reconciliation skeleton, and execution-history pagination.

## v4 integration notes

1. Copy `src/agora/state-dir.ts` and `src/agora/auth-manager.ts` into the Kairos repo with the rest of `src/agora`.
2. Set `KAIROS_DATA_DIR=/var/lib/kairos` or equivalent on Vultr so all Angora JSON state is stored under `$KAIROS_DATA_DIR/agora`.
3. Use `AGORA_API_KEY` only as a bootstrap/admin key, then create scoped hashed keys via `/v1/agora/auth/keys`.
4. Mount `registerAgoraRoutes(app)` in the Kairos dashboard/server entrypoint.
5. If Kairos exposes a settlement-status endpoint, configure `AGORA_SETTLEMENT_HYDRATION_URL`; otherwise the demo reconciliation path keeps pending receipts honest and marks eligible non-fallback receipts settled after the configured demo delay.
